Note about Governance and Permission files:
-------------------------------------------

Governance and Permission files have been updated to be compatible with the latest release for RTI Connext DDS, and are compatible with RTI Connext DDS 5.2.6 and 5.2.7.

If you are compiling RTI Perftest against 5.2.5, you will need to get the certificates from the release/2.0 branch. You can do that by using the following git command:

git checkout release/2.0 -- resource/secure
